# Containers
------------

Containers are meant to be components that will contain business logic within your application. Say for example we wanted to build a BookMapContainer. This will be a portfolio selector that directly talks to our bookmap webservice, gets the books, and passes them a `component` that component should be a generic
control that just takes props and renders. 

So,

BookMapContainer
    -> Gets books from service
    -> renders <TreeComponent nodes={bookNodes} />


TreeComponent is our presentational control, it shouldnt know about the app. Containers should work more like singletons, these are the core of your app.