# Entrypoints
------------

The purpose of an entrypoint is to define where your application starts. These should mimic the "entry" section within the webpack.config.js file.


## There should in most cases only exist 3 files. 

1) index.js - this is where you do the actual rendering to the dom or do one time initialize of any libs that need to be required into the global namespace.

IE:
    require('webix/webix.js');
    require('webix/style/main.css');


2) main.js - your application starts here, this is where you should import your containers. This class should always be named Main. If you do change make sure to update in `index.js` respectively.

3) main.less - This is for your default global CSS. We do lately prefer material-ui for styling though so please consider that as an alternative for less styling.


# What should not go here
-------------------------

Any application logic. That belongs in either containers or components. If you have a class that is more utility we suggest creating a folder under src/

- api/<module>.js - this would be used for re-useable functions that do something like spawn a window or talk to a service

- <utility class>/<something>.js - these would exist for classes that have general purpose. Such as an eventing lib.