import React from 'react';
import {Button, Icon} from "@blueprintjs/core";
import { Example, IExampleProps } from "@blueprintjs/docs-theme";
import {render} from 'react-dom';

require('./main.less');

const pathToModule = require.resolve('.')

class Main extends React.Component {

	test() {
		var i = 123;
		for (let i=0; i < 10; i++) {
			console.log(['in', i]);
		}
		console.log(['out', i]);
		return i;
	}

    render() {
        return (
            <Example options={false} {...this.props}>
                {/* icon and rightIcon props */}
                <Button icon="refresh" intent="danger" text="Reset" />
                <Button icon="user" rightIcon="caret-down" text="Profile settings" />
                <Button rightIcon="arrow-right" intent="success" text="Next step" />
                {/* <Icon> children as inline text elements */}
                <Button>
                    <Icon icon="document" /> Upload... <Icon icon="small-cross" />
                </Button>
            </Example>
        )
    }
}

export default Main;
