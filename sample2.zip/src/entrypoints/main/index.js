import React from 'react';
import {render} from 'react-dom';
import Main from './main';
import DataGrid from './aggrid'
import {
    Intent,
    Icon,
    Alignment,
    Button,
    Classes,
    H5,
    Navbar,
    NavbarDivider,
    NavbarGroup,
    Menu,
    MenuItem,
    MenuDivider,
    NavbarHeading,
    Switch,
    NonIdealState,
    Position,
    Popover,
    Tabs,
    Tab
} from "@blueprintjs/core";
import { Hotkey, Hotkeys, HotkeysTarget } from "@blueprintjs/core";
import { IconNames } from "@blueprintjs/icons";
import { Drawer, Button as AntButton } from 'antd';
import { Divider, Layout, Menu as AntMenu } from 'antd';
import { Icon as AntIcon } from 'antd';
const { Header, Sider, Content } = Layout;


@HotkeysTarget
class SiderDemo extends React.Component {

    state = {
      collapsed: false,
      selectedTabId: "rx",
      selectedMenuItem: ['1']
    };
  
    toggle = () => {
      this.setState({
        collapsed: !this.state.collapsed,
      });
    }

    handleNavbarTabChange = (newValue) => {
        this.setState({
            selectedTabId: newValue
        })
    }

    renderHotkeys() {
        return <Hotkeys>
            <Hotkey
                global={true}
                combo="shift + 1"
                label="Be awesome all the time"
                onKeyDown={() => this.setState({selectedMenuItem: ["1"]})}
            />
            <Hotkey
                group="Fancy shortcuts"
                combo="shift + 2"
                label="Be fancy only when focused"
                onKeyDown={() => this.setState({selectedMenuItem: ["2"]})}
            />
        </Hotkeys>;
    }
    
    onMenuSelect = (item) => {
        this.setState({selectedMenuItem: [item['key']]})
    } 
  
    render() {

        const exampleMenu = (
            <Menu>
                <MenuItem icon="graph" text="Graph" />
                <MenuItem icon="map" text="Map" />
                <MenuItem icon="th" text="Table" shouldDismissPopover={false} />
                <MenuItem icon="zoom-to-fit" text="Nucleus" disabled={true} />
                <MenuDivider />
                <MenuItem icon="cog" text="Settings...">
                    <MenuItem icon="add" text="Add new application" disabled={true} />
                    <MenuItem icon="remove" text="Remove application" />
                </MenuItem>
            </Menu>
        );


      return (
          <Layout hasSider={true}>
            <Sider
                collapsible
                collapsedWidth={60}
                collapsed={this.state.collapsed}
                onCollapse={this.toggle}
                className="sider">

                <AntMenu theme="dark" mode="inline" 
                    onSelect={this.onMenuSelect}
                    selectedKeys={this.state.selectedMenuItem}>
                <AntMenu.Item key="1">
                    <AntIcon type="user" />
                    <span>nav 1</span>
                </AntMenu.Item>
                <AntMenu.Item key="2">
                    <AntIcon type="video-camera" />
                    <span>nav 2</span>
                </AntMenu.Item>
                <AntMenu.Item key="3">
                    <AntIcon type="upload" />
                    <span>nav 3</span>
                </AntMenu.Item>
                </AntMenu>
            </Sider>
            <Header style={{ position: 'fixed', padding: 0, margin: 0 }}>
                <Navbar className="bp3-dark">
                    <NavbarGroup>
                        <Icon 
                            icon={this.state.collapsed ? IconNames.MENU_OPEN : IconNames.MENU_CLOSED} 
                            iconSize={Icon.SIZE_STANDARD} 
                            onClick={this.toggle}
                            className="trigger" />
                        <NavbarDivider />
                        <Button className={Classes.MINIMAL} icon="home" text="Home" />
                        <Button className={Classes.MINIMAL} icon="document" text="Files" />
                    </NavbarGroup>
                </Navbar>
            </Header>
            <Content className="data-content">
                {/* <NonIdealState
                        icon="search"
                        title="No flash data loaded"
                        description="testando blah blah"
                        action={true}
                    /> */}

                
                <Menu className={Classes.ELEVATION_1} style={{width: 150}}>
                    <Divider>Center</Divider>
                    <MenuItem icon="new-text-box" text="New text box" />
                    <Divider orientation="right">... Right</Divider>
                    <MenuItem icon="new-object" text="New object" />
                    <MenuItem icon="new-link" text="New link" />
                    <Divider orientation="left">Left ...</Divider>
                    <MenuItem icon="cog" labelElement={<Icon icon="share" />} text="Settings..." />
                </Menu>

                <Popover content={exampleMenu} position={Position.RIGHT_BOTTOM}>
                    <Button icon="share" text="Open in..." />
                </Popover>

                <Tabs id="TabsExample" 
                    // onChange={this.handleTabChange} 
                    animate={true}
                    id="TabsExample"
                    key="horizontal"
                    renderActiveTabPanelOnly={true}
                    vertical={false}
                    selectedTabId={this.state.selectedTabId}
                    onChange={this.handleNavbarTabChange}>

                    <Tab id="ng" title="Angular" panel={<AngularPanel />} />
                    <Tab id="mb" title="Ember" panel={<EmberPanel />} />
                    <Tab id="rx" title="React" panel={<ReactPanel />} />
                    <Tab id="bb" disabled title="Backbone" panel={<BackbonePanel />} />
                    <Tabs.Expander />
                    <input className="bp3-input" type="text" placeholder="Search..." />
                </Tabs>
            </Content>
          </Layout> 

      );
    }
  }


const ReactPanel = props => (
    <DataGrid />
);

const AngularPanel = props => (
    <div>
        <h3>Example panel: Angular</h3>
        <p className={Classes.RUNNING_TEXT}>
            HTML is great for declaring static documents, but it falters when we try to use it for declaring dynamic
            views in web-applications. AngularJS lets you extend HTML vocabulary for your application. The resulting
            environment is extraordinarily expressive, readable, and quick to develop.
        </p>
    </div>
);

const EmberPanel = props => (
    <div>
        <h3>Example panel: Ember</h3>
        <p className={Classes.RUNNING_TEXT}>
            Ember.js is an open-source JavaScript application framework, based on the model-view-controller (MVC)
            pattern. It allows developers to create scalable single-page web applications by incorporating common idioms
            and best practices into the framework. What is your favorite JS framework?
        </p>
        <input className={Classes.INPUT} type="text" />
    </div>
);

const BackbonePanel = props => (
    <div>
        <h3>Backbone</h3>
    </div>
);

render(<SiderDemo />, document.getElementById('root'));