import React from 'react';
import { Button } from '@blueprintjs/core';
import { AgGridReact } from 'ag-grid-react';

class DataGrid extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            columnDefs: [
                {headerName: "Make", 
                 field: "make", 
                 checkboxSelection: true},
                {headerName: "Model", field: "model"},
                {headerName: "Price", field: "price"}

            ],
            rowData: []
        }
    }

    componentDidMount() {
        fetch('https://api.myjson.com/bins/15psn9')
            .then(result => result.json())
            .then(rowData => this.setState({rowData}))
    }

    onButtonClick = (e) => {
        const selectedNodes = this.gridApi.getSelectedNodes()  
        const selectedData = selectedNodes.map( node => node.data )
        const selectedDataStringPresentation = selectedData.map( node => node.make + ' ' + node.model).join(', ')
        alert(`Selected nodes: ${selectedDataStringPresentation}`) 
    }

    render() {
        return (
            <div 
                className="ag-theme-balham-dark"
                style={{ 
                height: '500px', 
                width: '100%' }}>
                <Button onClick={this.onButtonClick} text="GetRows" />
                <AgGridReact
                    rowSelection="multiple"
                    onGridReady={ params => this.gridApi = params.api }
                    enableSorting={true}
                    enableFilter={true}
                    columnDefs={this.state.columnDefs}
                    rowData={this.state.rowData}>
                </AgGridReact>
            </div>
        );
    }
}

export default DataGrid;