# Components
------------

Components are the building blocks for your application. They are your own custom UI Library. As a rule components should only import javascript libs and other components. You should NEVER import anything from inside your project outside of the components directory. You should also never connect something like Redux to a component. You should instead use the Component in a Container and connect the container to redux. This will allow you to re-use these controls. 

So,

TreeComponent
    -> Gets a `node` prop passed from BookMapContainer
    -> Builds a UI Component based around the passed property
    -> renders a tree control


