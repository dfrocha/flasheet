# Openfin Boiler Plate
---
This repository is provided as a starting point. Please fork this into your own repository and start building on it. If you have any suggestions on how it can be improved please contact DG FICC UI Developers. We want this process to be as easy as possible.

## Creating a new repository from the Boiler Plate
1. Clone this repository `git clone ssh://git@code.bankofamerica.com:7999/ficcshared/openfin_boiler.git`
2. From the root of the project run `node bin/setup.js` answer the questions accordingly
3. Install any deps `npm install --verbose`
4. Launch the openfin application `bin/remote.sh npm start` and start development
  
### Entry
The entry point for the application is located under [src/apps/main/main.js](http://code.bankofamerica.com:7990/projects/FICCSHARED/repos/openfin_boiler/browse/src/entrypoints/main/main.js) 

## Requirements
1. [Install Git](http://code.bankofamerica.com/docs/display/CODE/Setting+up+Git)
2. [Install NodeJS](http://esupport.bankofamerica.com:8080/sdccommon/asp/contentredirect.asp?sprt_cid=9a8b48c1-39db-4412-beae-ced803a91eae)

## Technologies used
[Openfin](https://openfin.co)
[Webpack2](https://webpack.js.org)  
[React](https://facebook.github.io/react/)  
[JSX](https://facebook.github.io/react/docs/introducing-jsx.html)  
[LESS](http://lesscss.org/)  
[ES6](http://es6-features.org/#Constants)  
[Babel](https://babeljs.io/)  
