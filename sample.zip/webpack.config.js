const webpack = require('webpack');
const path    = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const execSync = require('child_process').execSync;
const CURRENT_BRANCH_NAME = (process.env.BRANCH_NAME) ? process.env.BRANCH_NAME : execSync('git rev-parse --abbrev-ref HEAD').toString().trim();

module.exports = {
    entry: {
        main: path.resolve(__dirname, 'src/entrypoints/main', 'index.js'),
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.[name].js'
    },
    resolve: {
        alias: {
            'components': path.resolve(__dirname, 'src'),
            'state': path.resolve(__dirname, 'src/state'),
            'reducers': path.resolve(__dirname, 'src/reducers'),
            'actions': path.resolve(__dirname, 'src/actions'),
        },
    },    
    module: {
        rules: [
            { 
                test: /(\.jsx|\.js)$/, 
                loader: 'babel-loader',
                exclude: /(node_modules|public_libs)/,
                query: {
                    presets: ['es2015', 'react'],
                    plugins: ['transform-runtime']

                }
            },
            {
                test: /\.(css|less)$/,
                use: ExtractTextPlugin.extract({
                    loader: [{
                        loader: 'css-loader'    
                    }, {
                        loader: 'less-loader'
                    }]
                })
            }
        ],
    },
    plugins: [
        new ExtractTextPlugin('styles.[name].css'),
        new webpack.ProvidePlugin ({
            ReactDOM: 'react-dom',
            React: 'react',     
        }),
        new webpack.DefinePlugin({
            BRANCH_NAME: JSON.stringify(CURRENT_BRANCH_NAME)
        })
    ]
}


