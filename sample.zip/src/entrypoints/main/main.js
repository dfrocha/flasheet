import React from 'react';
import {render} from 'react-dom';

require('./main.less');

const pathToModule = require.resolve('.')

class Main extends React.Component {

	test() {
		var i = 123;
		for (let i=0; i < 10; i++) {
			console.log(['in', i]);
		}
		console.log(['out', i]);
		return i;
	}

    render() {
        return (
            <div id='main'>
            	Testando 123 {this.test()}
            </div>
        )
    }
}

export default Main;
